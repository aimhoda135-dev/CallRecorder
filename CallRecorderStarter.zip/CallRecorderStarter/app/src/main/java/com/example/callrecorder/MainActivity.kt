package com.example.callrecorder

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class Recording(
    val title: String,
    val date: String,
    val duration: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CallRecorderTheme {
                CallRecorderApp()
            }
        }
    }
}

@Composable
fun CallRecorderApp() {
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("سجل مكالماتي", fontWeight = FontWeight.Bold) }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Text("🏠") },
                    label = { Text("الرئيسية") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Text("🎙️") },
                    label = { Text("التسجيلات") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Text("⚙️") },
                    label = { Text("الإعدادات") }
                )
            }
        }
    ) { padding ->
        when (selectedTab) {
            0 -> HomeScreen(Modifier.padding(padding))
            1 -> RecordingsScreen(Modifier.padding(padding))
            2 -> SettingsScreen(Modifier.padding(padding))
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text("حالة التطبيق", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                Text("جاهز للعمل")
                Spacer(Modifier.height(8.dp))
                Text(
                    "التطبيق لن يسجل المكالمات بشكل سري، وسيستخدم فقط الطرق التي يسمح بها جهاز أندرويد."
                )
            }
        }

        Spacer(Modifier.height(28.dp))

        Button(
            onClick = { /* سيتم ربطه لاحقًا بميزة التسجيل */ },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Text("اختبار التسجيل")
        }

        Spacer(Modifier.height(12.dp))

        OutlinedButton(
            onClick = { /* سيتم لاحقًا فحص دعم الجهاز */ },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("فحص دعم الجهاز لتسجيل المكالمات")
        }
    }
}

@Composable
fun RecordingsScreen(modifier: Modifier = Modifier) {
    val recordings = listOf(
        Recording("تسجيل تجريبي", "23 سبتمبر 2026", "00:32"),
        Recording("لا توجد تسجيلات فعلية بعد", "", "")
    )

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(recordings) { recording ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(recording.title, fontWeight = FontWeight.Bold)
                    if (recording.date.isNotEmpty()) {
                        Text(recording.date)
                        Text(recording.duration)
                    } else {
                        Text("هذه مجرد واجهة مؤقتة إلى أن نضيف التخزين والتسجيل.")
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {
        Text("الإعدادات", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(20.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("الخصوصية", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("التسجيلات ستُحفظ محليًا على الجهاز في النسخة الأولى.")
            }
        }

        Spacer(Modifier.height(12.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("تسجيل المكالمات", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("سيتم تفعيل الوظيفة فقط عندما تكون مدعومة فعليًا من النظام والجهاز.")
            }
        }
    }
}

@Composable
fun CallRecorderTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(),
        content = content
    )
}
